# kyt/modules/license.py
import os, urllib.request, ssl, datetime

OWNER="asloma1984"; REPO="NorthAfrica"; REF="main"
TOKEN_FILE="/etc/kyt/.gh_token"

def _read_token():
    if os.path.isfile(TOKEN_FILE):
        return open(TOKEN_FILE).read().strip()
    return os.environ.get("GH_TOKEN","").strip()

def fetch_register():
    token=_read_token()
    if not token:
        raise RuntimeError("Missing GitHub token in /etc/kyt/.gh_token or GH_TOKEN")
    url=f"https://api.github.com/repos/{OWNER}/{REPO}/contents/register?ref={REF}"
    req=urllib.request.Request(url,headers={
        "Authorization":f"token {token}",
        "Accept":"application/vnd.github.raw",
        "User-Agent":"kyt-bot"
    })
    ctx=ssl.create_default_context()
    with urllib.request.urlopen(req,context=ctx,timeout=15) as r:
        return r.read().decode("utf-8","ignore")

def _today_iso():
    try:
        with urllib.request.urlopen("https://google.com",timeout=5) as r:
            from email.utils import parsedate_to_datetime
            d=r.headers.get("Date")
            if d: return parsedate_to_datetime(d).date().isoformat()
    except Exception: pass
    return datetime.date.today().isoformat()

def _public_ip():
    with urllib.request.urlopen("https://ipv4.icanhazip.com",timeout=5) as r:
        return r.read().decode().strip()

def check_license_or_raise():
    ip=_public_ip()
    today=_today_iso()
    reg=fetch_register()
    exp=None
    for line in reg.splitlines():
        p=line.strip().split()
        if len(p)>=4 and p[0]=="###" and p[3]==ip:
            exp=p[2]; break
    if not exp:
        raise PermissionError(f"IP {ip} is not registered")
    if today>exp:
        raise PermissionError(f"License expired (today={today}, exp={exp})")
    return True