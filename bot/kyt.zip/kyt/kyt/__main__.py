from kyt.modules.license import check_license_or_raise
try:
    check_license_or_raise()
except Exception as e:
    print(f"[License] {e}")
    raise SystemExit(1)

from kyt import *
from importlib import import_module
from kyt.modules import ALL_MODULES

for module_name in ALL_MODULES:
    import_module("kyt.modules." + module_name)

bot.run_until_disconnected()