# -*- coding: utf-8 -*-
"""
Core helpers for the Telegram bot (DB + config + small utils).
Keeps original behavior but cleans imports and makes config loading safer.
"""

import os
import sys
import re
import json
import math
import time
import base64
import random
import sqlite3
import subprocess
import requests
import logging
from datetime import datetime as DT
from telethon import TelegramClient

logging.basicConfig(level=logging.INFO)
uptime = DT.now()

# ------------------------------------------------------------
# Load variables from var.txt (BOT_TOKEN, ADMIN, TG_API_ID, TG_API_HASH, ...)
# Tries these paths in order:
#   ./kyt/var.txt            (relative to current working dir)
#   /usr/bin/kyt/var.txt
#   /usr/local/bin/kyt/var.txt
# ------------------------------------------------------------
def _load_vars():
    candidate_paths = [
        os.path.join(os.getcwd(), "kyt", "var.txt"),
        "/usr/bin/kyt/var.txt",
        "/usr/local/bin/kyt/var.txt",
    ]
    env = {}
    for path in candidate_paths:
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as f:
                code = compile(f.read(), path, "exec")
                # exec into our local dict (like your original exec)
                exec(code, env, env)
            logging.info("Loaded vars from %s", path)
            break
    else:
        raise FileNotFoundError(
            "var.txt not found in ./kyt/var.txt or /usr/bin/kyt/var.txt or /usr/local/bin/kyt/var.txt"
        )

    # Keep same variable names you use elsewhere
    cfg = {
        "BOT_TOKEN": env.get("BOT_TOKEN"),
        "ADMIN": env.get("ADMIN"),
        "TG_API_ID": env.get("TG_API_ID", 6),  # defaults kept for compatibility
        "TG_API_HASH": env.get("TG_API_HASH", "eb06d4abfb49dc3eeb1aeb98ae0f581e"),
        "DOMAIN": env.get("DOMAIN", ""),
        "PUB": env.get("PUB", ""),
        "HOST": env.get("HOST", ""),
    }

    # minimal sanity
    if not cfg["BOT_TOKEN"]:
        raise RuntimeError("BOT_TOKEN is missing in var.txt")
    if not cfg["TG_API_ID"] or not cfg["TG_API_HASH"]:
        raise RuntimeError("TG_API_ID / TG_API_HASH are missing in var.txt")

    return cfg


CFG = _load_vars()

# ------------------------------------------------------------
# Telegram client (keeps your original .start(bot_token=...))
# ------------------------------------------------------------
# session name kept (you had "ddsdswl")
bot = TelegramClient(
    "ddsdswl",
    int(CFG["TG_API_ID"]),
    str(CFG["TG_API_HASH"])
).start(bot_token=CFG["BOT_TOKEN"])

# ------------------------------------------------------------
# SQLite admin DB bootstrap (same logic you had)
# ------------------------------------------------------------
DB_DIR = "kyt"
DB_PATH = os.path.join(DB_DIR, "database.db")
os.makedirs(DB_DIR, exist_ok=True)

try:
    open(DB_PATH).close()
except Exception:
    x = sqlite3.connect(DB_PATH)
    c = x.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS admin (user_id)")
    c.execute("INSERT INTO admin (user_id) VALUES (?)", (str(CFG["ADMIN"]),))
    x.commit()
    x.close()

def get_db():
    x = sqlite3.connect(DB_PATH)
    x.row_factory = sqlite3.Row
    return x

def valid(id):
    db = get_db()
    rows = db.execute("SELECT user_id FROM admin").fetchall()
    admins = [v[0] for v in rows]
    db.close()
    if str(id) in [str(a) for a in admins]:
        return "true"
    else:
        return "false"

def convert_size(size_bytes):
    """Return human-readable byte size (kept same behavior)."""
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])